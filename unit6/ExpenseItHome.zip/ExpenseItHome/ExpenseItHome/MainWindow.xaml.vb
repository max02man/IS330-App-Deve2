﻿Class MainWindow 

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles Button1.Click
        TextBlock1.Text = peopleListBox.SelectedItem.Content.ToString
    End Sub

    Private Sub Window_Loaded(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles MyBase.Loaded

        Dim AddressBookDataSet As ExpenseItHome.AddressBookDataSet = CType(Me.FindResource("AddressBookDataSet"), ExpenseItHome.AddressBookDataSet)
        'Load data into the table Addresses. You can modify this code as needed.
        Dim AddressBookDataSetAddressesTableAdapter As ExpenseItHome.AddressBookDataSetTableAdapters.AddressesTableAdapter = New ExpenseItHome.AddressBookDataSetTableAdapters.AddressesTableAdapter()
        AddressBookDataSetAddressesTableAdapter.Fill(AddressBookDataSet.Addresses)
        Dim AddressesViewSource As System.Windows.Data.CollectionViewSource = CType(Me.FindResource("AddressesViewSource"), System.Windows.Data.CollectionViewSource)
        AddressesViewSource.View.MoveCurrentToFirst()
    End Sub
End Class
