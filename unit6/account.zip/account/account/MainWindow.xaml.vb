﻿Class MainWindow 

    Private total As Decimal = 0D
    Public Sub Number_Click(ByVal source As Object, ByVal e As RoutedEventArgs) Handles Button9.Click, Button11.Click, Button0.Click, Button8.Click, Button7.Click, Button4.Click, Button5.Click, Button6.Click, Button3.Click, Button2.Click, Button1.Click

        enter.Text = enter.Text &
           CChar(CType(source, Button).Content)
    End Sub
    Private Sub ent_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles ent.Click
        If (enter.Text.Length > 0) Then
            total += CDec(enter.Text)
        End If
        enter.Text = String.Empty
    End Sub

    Private Sub clear_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles clear.Click
        If enter.Text.Length > 0 Then
            total += CDec(enter.Text)
            enter.Text = String.Empty
        End If


        subtext.Text = String.Format("{0:0.00}", total)
        tax.Text = String.Format("{0:0.00}", 0.05 * total)
        totaltext.Text = String.Format("{0:0.00}", 1.05 * total)
    End Sub

    Private Sub del_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles del.Click
        enter.Text = String.Empty
    End Sub

    Private Sub tot_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles tot.Click
        enter.Text = String.Empty
        subtext.Text = String.Empty
        tax.Text = String.Empty
        totaltext.Text = String.Empty

        total = 0D
    End Sub

  
End Class
