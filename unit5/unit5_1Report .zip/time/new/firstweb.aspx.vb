﻿
Partial Class firstweb
    Inherits System.Web.UI.Page

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        timeLabel.Text = DateTime.Now.ToString("hh:mm:ss")
    End Sub
End Class
