﻿
Partial Class WebControls
    Inherits System.Web.UI.Page

    Protected Sub registerButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles registerButton.Click
        Dim fname As String = firstNameTextBox.Text
        Dim lname As String = lastNameTextBox.Text
        Dim name As String = fname & " " & lname
        Dim email As String = emailTextBox.Text
        Dim phone As String = phoneTextBox.Text

        outputLabel.Text = "Thank you for your submission<br/." &
            "We received the following information:<br/>"
        outputLabel.Text &=
            String.Format("Name:{0}{1}E-mail:{2}{1}Phone:{3}{1}",
                          name, "<br/>", email, phone, "<br/>")

        Dim book As String = DropDownList1.SelectedValue
        outputLabel.Text &=
            String.Format("Book:{0}{1}", book, "<br/>")

        Dim OS As String = osRadioButtonList.SelectedValue

        outputLabel.Text &=
            String.Format("OS:{0}{1}", OS, "<br/>")
    End Sub
End Class
