﻿
Partial Class guestbook
    Inherits System.Web.UI.Page

    Protected Sub submitButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SubmitButton.Click
        Dim insertParameters As New ListDictionary()

        insertParameters.Add("Date", Date.Now.ToShortDateString())
        insertParameters.Add("Name", nameTextBox.Text)
        insertParameters.Add("Email", emailTextBox.Text)
        insertParameters.Add("Message", messageTextBox.Text)

        messagesLinqDataSource.Insert(insertParameters)

        nameTextBox.Text = String.Empty
        emailTextBox.Text = String.Empty
        messageTextBox.Text = String.Empty

        messageGridView.DataBind()
    End Sub

    Protected Sub clearButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles clearButton.Click
        nameTextBox.Text = String.Empty
        emailTextBox.Text = String.Empty
        messageTextBox.Text = String.Empty
    End Sub
End Class
