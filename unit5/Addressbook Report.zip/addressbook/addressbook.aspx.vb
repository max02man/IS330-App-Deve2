﻿
Partial Class addressbook
    Inherits System.Web.UI.Page


    Protected Sub addressGridView_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles addressGridView.SelectedIndexChanged

    End Sub

    Protected Sub searchButton_Click(sender As Object, e As System.EventArgs) Handles searchButton.Click
        GridView1.Visible = False
    End Sub

    Protected Sub clearbutton_Click(sender As Object, e As System.EventArgs) Handles clearbutton.Click
        searchTextBox.Text = String.Empty
        GridView1.Visible = True
    End Sub
End Class
