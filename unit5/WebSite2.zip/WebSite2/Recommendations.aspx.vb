﻿
Partial Class Recommendations
    Inherits System.Web.UI.Page
    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        If Session.Count <> 0 Then
            For Each keyName In Session.Keys
                booksListBox.Items.Add(keyName &
                                       " How to Program. ISBN#: " & Session(keyName))
            Next
        Else
            recommendationsLabel.Text = "No recommendations"
            booksListBox.Items.Clear()
            booksListBox.Visible = False

            languageLink.Text = "Click here to choose a language"
        End If
    End Sub
End Class
