﻿
Partial Class options
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If IsPostBack Then
            responseLabel.Visible = True
            idLabel.Visible = True
            timeoutLabel.Visible = True
            languageLink.Visible = True
            recommendationsLink.Visible = True

            promptLabel.Visible = False
            languageList.Visible = False
            submitButton.Visible = False

            If languageList.SelectedItem IsNot Nothing Then
                responseLabel.Text &= " You selected " & languageList.SelectedItem.Text
            Else
                responseLabel.Text &= " You did not select a language"
            End If

            idLabel.Text = "Your unique session ID is: " & Session.SessionID
            timeoutLabel.Text = "Timeout: " & Session.Timeout & "minutes."
        End If
    End Sub

    Protected Sub submitButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles submitButton.Click
        If languageList.SelectedItem IsNot Nothing Then
            Session.Add(languageList.SelectedItem.Text, languageList.SelectedItem.Value)
        End If
    End Sub
End Class
