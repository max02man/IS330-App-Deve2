﻿
Partial Class ajlx
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        System.Threading.Thread.Sleep(3000)
        Label1.Text = Date.Now
        Label2.Text = Date.Now
        Label3.Text = Date.Now
    End Sub
End Class
