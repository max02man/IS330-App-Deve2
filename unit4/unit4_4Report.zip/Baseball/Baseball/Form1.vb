﻿Public Class Form1
    Private database As New BaseballDataContext()
    Private Sub refreshcontacts()
        PlayerBindingSource.DataSource =
            From player In database.Players
            Order By player.PlayerID
            Select player

        PlayerBindingSource.MoveFirst()
        searchTextBox.Clear()

    End Sub
    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        refreshcontacts()

    End Sub
    Private Sub PlayerBindingNavigatorSaveItem_Click(sender As System.Object, e As System.EventArgs) Handles PlayerBindingNavigatorSaveItem.Click
        Validate()
        PlayerBindingSource.EndEdit()
        database.SubmitChanges()
        refreshcontacts()

    End Sub

    Private Sub searchButton_Click(sender As System.Object, e As System.EventArgs) Handles searchButton.Click
        PlayerBindingSource.DataSource =
            From player In database.Players
            Where player.LastName.StartsWith(searchTextBox.Text)
            Order By player.PlayerID
            Select player

        PlayerBindingSource.MoveFirst()
       
            Label1.Text = LastNameTextBox.Text

    End Sub

    Private Sub clearButton_Click(sender As System.Object, e As System.EventArgs) Handles clearButton.Click
        Label1.Text = String.Empty
        searchTextBox.Text = String.Empty
    End Sub
End Class
