﻿Public Class Form1
    Private datebase As New BooksDataContext()



    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        TitleBindingSource.DataSource =
            From title In datebase.Titles
            Order By title.Title
            Select title
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        AuthorBindingSource.DataSource =
            From author In datebase.Authors
            Order By author.AuthorID
            Select author
    End Sub

    Private Sub AuthorBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AuthorBindingNavigatorSaveItem.Click
        Validate()
        AuthorBindingSource.EndEdit()
        datebase.SubmitChanges()
    End Sub
End Class
