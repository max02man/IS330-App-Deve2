﻿Public Class Form1
    Private database As New BookDataContext
    Private Sub queriesComboBox_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles queriesComboBox.SelectedIndexChanged
        Select Case queriesComboBox.SelectedIndex
            Case 0
                TitleBindingSource.DataSource =
                    From book In database.Titles
                    Order By book.Title
                    Select book
            Case 1
                TitleBindingSource.DataSource =
                    From book In database.Titles
                    Where book.Copyright = "2008"
                    Order By book.Title
                    Select book
            Case 2
                TitleBindingSource.DataSource =
                    From book In database.Titles
                    Where book.Title.EndsWith("How to Program")
                    Order By book.Title
                    Select book

        End Select
        TitleBindingSource.MoveFirst()
    End Sub

    Private Sub Titlequeries_load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        queriesComboBox.SelectedIndex = 0
    End Sub

    Private Sub TitleBindingNavigatorSaveItem_Click(sender As System.Object, e As System.EventArgs) Handles TitleBindingNavigatorSaveItem.Click
        Validate()
        TitleBindingSource.EndEdit()
        database.SubmitChanges()
        queriesComboBox.SelectedIndex = 0

    End Sub
End Class
