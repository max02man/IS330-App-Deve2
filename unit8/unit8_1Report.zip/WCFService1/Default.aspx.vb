﻿
Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As System.EventArgs) Handles Button1.Click
        Dim client As New localhost.demoService
        Label1.Text = client.sayhelloworld
    End Sub

    Protected Sub Button2_Click(sender As Object, e As System.EventArgs) Handles Button2.Click
        Dim client2 As New net.webservicex.www.StockQuote
        TextBox2.Text = client2.GetQuote(TextBox1.Text)

    End Sub

End Class
