﻿' NOTE: You can use the "Rename" command on the context menu to change the class name "Service" in code, svc and config file together.
Public Class demoService
    Implements IdemoService

    Public Sub New()
    End Sub

    Public Function GetData(ByVal value As Integer) As String Implements IdemoService.GetData
        Return String.Format("You entered: {0}", value)
    End Function

    Public Function GetDataUsingDataContract(ByVal composite As CompositeType) As CompositeType Implements IdemoService.GetDataUsingDataContract
        If composite Is Nothing Then
            Throw New ArgumentNullException("composite")
        End If
        If composite.BoolValue Then
            composite.StringValue &= "Suffix"
        End If
        Return composite
    End Function

    Public Function Sayhelloworld() As String Implements IdemoService.sayhelloworld
        Return "Hello World, This is our first WCF web Service!!"
    End Function
End Class
