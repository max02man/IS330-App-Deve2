﻿
Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As System.EventArgs) Handles Button1.Click
       
        Dim wel As New localhost.weatherService
        Label1.Text = wel.conversion()

        'Dim con As New net.webservicex.www.ConvertTemperature
        ' TextBox2.Text = con.ConvertTemp(TextBox1.Text, TextBox3.Text, TextBox4.Text)
    End Sub
End Class
