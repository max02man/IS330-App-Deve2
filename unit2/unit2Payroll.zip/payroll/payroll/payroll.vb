﻿Public Class payroll

    Public Const BonusRate As Decimal = 1.45D
    Public Const PayRate As Decimal = 14.75D
    Overridable Function PayEmployee(ByVal HoursWorked As Decimal, ByVal PayRate As Decimal) As Decimal
        Return HoursWorked * PayRate
    End Function

End Class
