﻿Public Class BonusPayroll
    Inherits payroll

    Overrides Function PayEmployee(ByVal HoursWorked As Decimal, ByVal PayRate As Decimal) As Decimal

        ' The following code calls the original method in the base class, and then modifies the returned value.

        Return MyBase.PayEmployee(HoursWorked, PayRate) * BonusRate

    End Function
End Class
