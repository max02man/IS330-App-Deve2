﻿Public Module testingPart

    Public Sub Main()

        RunPayroll()

    End Sub

    Sub RunPayroll()

        Dim PayrollItem As Payroll = New Payroll

        Dim BonusPayrollItem As New BonusPayroll

        Dim HoursWorked As Decimal = 40

        MsgBox("Normal pay is: " & PayrollItem.PayEmployee(HoursWorked, Payroll.PayRate))

        MsgBox("Pay with bonus is: " & BonusPayrollItem.PayEmployee(HoursWorked, Payroll.PayRate))

    End Sub
    Sub RunPayRoll2()
        Dim PayrollItem As OvertimePayroll = New OvertimePayroll

        Dim BonusPayrollItem As New BonusPayroll

        Dim HoursWorked As Decimal = 40
        Dim HoursWorked2 As Decimal = 45

        MsgBox("Normal pay is: " & PayrollItem.PayEmployee(HoursWorked, OvertimePayroll.PayRate))

        MsgBox("Pay with bonus is: " & BonusPayrollItem.PayEmployee(HoursWorked, OvertimePayroll.PayRate))

        MsgBox("pay for who has extra five hours in a week: " & BonusPayrollItem.PayEmployee(HoursWorked2,
                        OvertimePayroll.PayRate))
    End Sub
End Module