﻿Public Class Form1

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Dim salariedemployee As New SalariedEmployee("John", "Smith", "111-11-1111", 800D)
        Dim commissionemployee As New commissionemployee("Sue", "Jones", "333-33-3333", 10000D, 0.06)
        Dim basepluscommissionemployee As New basepluscommissionemployee("Bob",
        "Lewis", "444-44-4444", 5000D, 0.04, 300D)
        outputTextBox1.AppendText("Employee processed individually:" & vbCrLf & vbCrLf &
                                  String.Format("{0}{1}earned: {2:c}{1}{1}", salariedemployee.ToString(), vbCrLf,
                                                salariedemployee.calcuateearnings()) &
                                            String.Format("{0}{1}earned: {2:c}{1}{1}", commissionemployee.ToString(), vbCrLf,
                                               commissionemployee.calcuateearnings()) &
                                           String.Format("{0}{1}earned: {2:c}{1}{1}", basepluscommissionemployee.ToString(), vbCrLf,
                                                basepluscommissionemployee.calcuateearnings()))

        Dim employee() As Employee = {salariedemployee, commissionemployee, basepluscommissionemployee}

        outputTextBox2.AppendText("employees processed polymorphically: " & vbCrLf & vbCrLf)
        For Each currentemployee In employee
            outputTextBox2.AppendText(String.Format("{0}{1}earned {2:c}{1}{1}", currentemployee.ToString(), vbCrLf,
                                                    currentemployee.calcuateearnings()))
        Next

    End Sub
End Class
