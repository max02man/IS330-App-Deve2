﻿Public Class commissionemployee
    Inherits Employee
    Private grosssalesvalue As Decimal
    Private commissionratevalue As Double

    Public Sub New(ByVal first As String, ByVal last As String, ByVal ssn As String,
                    ByVal sales As Decimal, ByVal rate As Double)
        MyBase.New(first, last, ssn)
        grosssalesvalue = sales
        commissionratevalue = rate
    End Sub

    Public Property grosssales() As Decimal
        Get
            Return grosssalesvalue
        End Get
        Set(ByVal sales As Decimal)
            If sales >= 0D Then
                grosssalesvalue = sales
            Else
                Throw New ArgumentOutOfRangeException("Gross sales must be greater than or equal to 0")

            End If
        End Set
    End Property

    Public Property commisstionrate() As Decimal
        Get
            Return commissionratevalue
        End Get
        Set(ByVal rate As Decimal)
            If rate > 0.0 AndAlso rate < 1.0 Then
                commissionratevalue = rate
            Else
                Throw New ArgumentOutOfRangeException("Interest rate must be greater than 0 and less than 1")

            End If
        End Set
    End Property
    Public Overrides Function ToString() As String
        Return String.Format("commission employee: {0}{1}" &
                             "gross sales: {2:c}{1}commission rate: {3:f}",
                             MyBase.ToString(), vbCrLf, grosssales, commisstionrate)
    End Function
    Public Overrides Function calcuateearnings() As Decimal
        Return Convert.ToDecimal(commisstionrate) * grosssales
    End Function
End Class
