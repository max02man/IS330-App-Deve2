﻿Public MustInherit Class Employee
    Public Property firstname() As String
    Public Property lastname() As String
    Public Property socialsecuritynumber() As String

    Public Sub New(ByVal first As String, ByVal last As String, ByVal ssn As String)
        firstname = first
        lastname = last
        socialsecuritynumber = ssn
    End Sub
    Public Overrides Function ToString() As String
        Return String.Format("{0} {1}{2}{3} {4}", firstname, lastname, vbCrLf,
                             "social security number: ", socialsecuritynumber)
    End Function
    Public MustOverride Function calcuateearnings() As Decimal
End Class
