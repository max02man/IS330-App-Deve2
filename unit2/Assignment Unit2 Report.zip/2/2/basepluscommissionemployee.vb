﻿Public Class basepluscommissionemployee
    Inherits commissionemployee

    Private basesalaryvalue As Decimal

    Public Sub New(ByVal first As String, ByVal last As String, ByVal ssn As String,
                    ByVal sales As Decimal, ByVal rate As Double, salary As Decimal)
        MyBase.New(first, last, ssn, sales, rate)
        basesalary = salary
    End Sub

    Public Property basesalary() As Decimal
        Get
            Return basesalaryvalue
        End Get
        Set(salary As Decimal)
            If salary >= 0D Then
                basesalaryvalue = salary
            Else
                Throw New ArgumentOutOfRangeException("Base Salary must be greater than or equal to 0")

            End If
        End Set
    End Property


    Public Overrides Function ToString() As String
        Return String.Format("base-plus-{0}{1}base salary: {2:c}",
                             MyBase.ToString(), vbCrLf, basesalary)

    End Function
    Public Overrides Function calcuateearnings() As Decimal
        Return basesalary + MyBase.calcuateearnings()
    End Function
End Class
