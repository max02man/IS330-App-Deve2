﻿Public Class SalariedEmployee
    Inherits Employee
    Private weeklysalaryvalue As Decimal
    Public Sub New(ByVal first As String, ByVal last As String, ByVal ssn As String,
                     salary As Decimal)
        MyBase.New(first, last, ssn)

        weeklysalary = salary
    End Sub

    Public Property weeklysalary() As Decimal
        Get
            Return weeklysalaryvalue
        End Get
        Set(salary As Decimal)
            If salary >= 0D Then
                weeklysalaryvalue = salary
            Else
                Throw New ArgumentOutOfRangeException("Salary must be greater than or equal to 0")

            End If
        End Set
    End Property

    Public Overrides Function calcuateearnings() As Decimal
        Return weeklysalary
    End Function

    Public Overrides Function ToString() As String
        Return String.Format("salaried employee: {0}{1}weekly salary: {2:c}",
                             MyBase.ToString(), vbCrLf, weeklysalary)
    End Function
End Class
