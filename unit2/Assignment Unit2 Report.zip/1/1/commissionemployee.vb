﻿Public Class commissionemployee
    Public Property firstname() As String
    Public Property lastname() As String
    Public Property socialsecuritynumber() As String
    Private grosssalesvalue As Decimal
    Private commissionratevalue As Double

    Public Sub New(ByVal first As String, ByVal last As String, ByVal ssn As String,
                    ByVal sales As Decimal, ByVal rate As Double)
        firstname = first
        lastname = last
        socialsecuritynumber = ssn
        grosssalesvalue = sales
        commissionratevalue = rate
    End Sub

    Public Property grosssales() As Decimal
        Get
            Return grosssalesvalue
        End Get
        Set(ByVal sales As Decimal)
            If sales >= 0D Then
                grosssalesvalue = sales
            Else
                Throw New ArgumentOutOfRangeException("Gross sales must be greater than or equal to 0")

            End If
        End Set
    End Property

    Public Property commisstionrate() As Decimal
        Get
            Return commissionratevalue
        End Get
        Set(ByVal rate As Decimal)
            If rate > 0.0 AndAlso rate < 1.0 Then
                commissionratevalue = rate
            Else
                Throw New ArgumentOutOfRangeException("Interest rate must be greater than 0 and less than 1")

            End If
        End Set
    End Property

    Public Overridable Function calculateearning() As Decimal
        Return Convert.ToDecimal(commisstionrate) * grosssales
    End Function

    Public Overrides Function ToString() As String
        Return "Commission employee: " & firstname & " " & lastname & vbCrLf & "Social security number: " & socialsecuritynumber &
        vbCrLf & "gross sales: " & String.Format("{0:c}", grosssales) & vbCrLf & "commission rate: " & String.Format("{0:f}", commisstionrate)
    End Function
End Class
