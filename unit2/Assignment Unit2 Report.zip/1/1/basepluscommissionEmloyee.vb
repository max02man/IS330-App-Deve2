﻿Public Class basepluscommissionEmloyee
    Inherits commissionemployee

    Private basesalaryvalue As Decimal

    Public Sub New(ByVal first As String, ByVal last As String, ByVal ssn As String,
                    ByVal sales As Decimal, ByVal rate As Double, salary As Decimal)
        MyBase.New(first, last, ssn, sales, rate)
        basesalary = salary
    End Sub

    Public Property basesalary() As Decimal
        Get
            Return basesalaryvalue
        End Get
        Set(salary As Decimal)
            If salary >= 0D Then
                basesalaryvalue = salary
            Else
                Throw New ArgumentOutOfRangeException("Base Salary must be greater than or equal to 0")

            End If
        End Set
    End Property

    Public Overrides Function calculateearning() As Decimal
        Return basesalary + MyBase.calculateearning()
    End Function

    Public Overrides Function ToString() As String
        Return "base-plus-" & MyBase.ToString() & vbCrLf &
            "base salary: " & String.Format("{0:c}", basesalary)

    End Function

End Class
