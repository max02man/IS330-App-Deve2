﻿Public Class Form1

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim employee As New basepluscommissionEmloyee("Bob",
        "Lewis", "333-333-3333", 5000D, 0.04, 300D)

        outputTextBox.AppendText("employee inftomtion obtained by properties: " & vbCrLf &
                                 "first name is " & employee.firstname & vbCrLf & "last name is " &
                                 employee.lastname & vbCrLf & "Social security number is " & employee.socialsecuritynumber &
                                 vbCrLf & "gross sales is " & String.Format("{0:c}", employee.grosssales) &
                                 vbCrLf & "Commission rate is " & String.Format("{0:f}", employee.commisstionrate) &
                                 vbCrLf & "Base salary is " & String.Format("{0:c}", employee.basesalary))
        outputtextbox.appendtext(vbCrLf & vbCrLf & "Earnings: " & String.Format("{0:c}", employee.calculateearning()))

        employee.grosssales = 10000D
        employee.commisstionrate = 0.05
        employee.basesalary = 1000D

        outputTextBox.AppendText(vbCrLf & vbCrLf & "Updated employee information returned by ToString: " & vbCrLf & employee.ToString())

        outputtextbox.appendtext(vbCrLf & vbCrLf & "Earnings: " & String.Format("{0:c}", employee.calculateearning()))

    End Sub
End Class
