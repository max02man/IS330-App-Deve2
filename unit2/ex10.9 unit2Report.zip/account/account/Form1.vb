﻿Public Class Form1

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Dim account As New checkingaccount(50, 1000, 5)
        Dim account2 As New savingaccount(50, 1000, 0.02)
        TextBox1.AppendText("You Add to your account: " & String.Format("{0:C}", account.credit) & vbCrLf & vbCrLf &
                             "You Withdraw from your account " & String.Format("{0:C}", account.debit) & vbCrLf & vbCrLf &
                             "The Balance in your account is " & String.Format("{0:C}", account.balance) & vbCrLf & vbCrLf &
                             "The Fee charge is: " & String.Format("{0:C}", account.feecharge) & vbCrLf & vbCrLf &
                            "Your Balance plus the fee charge is " & String.Format("{0:C}", account.balance1()))

        TextBox2.AppendText("You Add to your account: " & String.Format("{0:C}", account2.credit) & vbCrLf & vbCrLf &
                             "You Withdraw from your account " & String.Format("{0:C}", account2.debit) & vbCrLf & vbCrLf &
                             "The Balance in your account is " & String.Format("{0:C}", account2.balance) & vbCrLf & vbCrLf &
                             "The interest rate is: " & Format(account2.instance, "Percent") & vbCrLf & vbCrLf &
                             "the amount of interest rate is " & String.Format("{0:C}", account2.calculaterate()))
    End Sub
End Class
