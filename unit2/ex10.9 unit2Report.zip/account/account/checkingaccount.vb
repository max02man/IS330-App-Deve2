﻿Public Class checkingaccount
    Inherits Account
    Public feecharge As Decimal
    Public Sub New(ByVal withdraw As Decimal, ByVal add As Decimal, ByVal fee As Decimal)
        MyBase.New(withdraw, add)
        feecharge = fee
    End Sub
    Public Overloads Function balance1() As Decimal
        Return MyBase.balance - feecharge
    End Function
End Class
