﻿Public Class Account
    Private balancevalue As Decimal
    Public credit As Decimal
    Public debit As Decimal
   
    Public Sub New(ByVal withdraw As Decimal, ByVal Add As Decimal)
        debit = withdraw
        credit = Add
        balancevalue += Add

        If withdraw > balancevalue Then
            Throw New ArgumentOutOfRangeException(
                "Tha debit amount exxeedef the account balance")
        Else
            balancevalue -= withdraw
        End If
    End Sub


    Public Property balance() As Decimal
        Get
            Return balancevalue
        End Get
        Set(ByVal value As Decimal)
            If value >= 0D Then
                balancevalue = value
            Else
                Throw New ArgumentOutOfRangeException(
                    "The initial balance must be greater than ot equal to 0")

            End If
        End Set
    End Property

    Public Overridable Function calculaterate() As Decimal
        Return balance
    End Function
End Class
