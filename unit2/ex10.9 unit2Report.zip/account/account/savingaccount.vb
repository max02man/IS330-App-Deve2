﻿Public Class savingaccount
    Inherits Account
    Public instance As Double

    Public Sub New(ByVal withdraw As Decimal, ByVal add As Decimal, ByVal rate As Double)
        MyBase.New(withdraw, add)
        instance = rate
    End Sub
    Public Overrides Function calculaterate() As Decimal
        Return instance * MyBase.calculaterate()
    End Function
End Class
