﻿Class MainWindow 
    ' stores the collection of points for the multi-sided shapes
    Private points As New PointCollection()


  


    Private Sub drawCanvas_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Input.MouseButtonEventArgs) Handles drawCanvas.MouseDown
        points.Add(e.GetPosition(drawCanvas)) ' add point to collection
    End Sub

    Private Sub clearButton_Click(ByVal sender As Object, ByVal e As System.Windows.RoutedEventArgs) Handles clearButton.Click
        points.Clear() ' clear the points from the collection
    End Sub

    Private Sub lineRadio_Checked(ByVal sender As Object, ByVal e As System.Windows.RoutedEventArgs) Handles lineRadio.Checked
        ' Polyline is visible, the other two are not
        polyLine.Visibility = Windows.Visibility.Visible
        polygon.Visibility = Windows.Visibility.Collapsed
        filledPolygon.Visibility = Windows.Visibility.Collapsed

    End Sub

    ' when the user selects the Polygon
    Private Sub polygonRadio_Checked(ByVal sender As Object,
       ByVal e As System.Windows.RoutedEventArgs) _
       Handles polygonRadio.Checked

        ' Polygon is visible, the other two are not
        polyLine.Visibility = Windows.Visibility.Collapsed
        polygon.Visibility = Windows.Visibility.Visible
        filledPolygon.Visibility = Windows.Visibility.Collapsed
    End Sub ' polygonRadio_Checked

    ' when the user selects the filled Polygon
    Private Sub filledPolygonRadio_Checked(ByVal sender As Object,
       ByVal e As System.Windows.RoutedEventArgs) _
       Handles filledPolygonRadio.Checked

        ' filled Polygon is visible, the other two are not
        polyLine.Visibility = Windows.Visibility.Collapsed
        polygon.Visibility = Windows.Visibility.Collapsed
        filledPolygon.Visibility = Windows.Visibility.Visible
    End Sub ' filledPolygonRadio_Checked


    Private Sub Window_Loaded(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles MyBase.Loaded
        polyLine.Points = points ' assign Polyline points
        polygon.Points = points ' assign Polygon points
        filledPolygon.Points = points ' assign filled Polygon points
    End Sub
End Class
