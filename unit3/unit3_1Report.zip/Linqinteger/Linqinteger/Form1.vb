﻿Public Class Form1

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Dim values() As Integer = {2, 9, 5, 0, 3, 7, 1, 4, 8, 6, -1, -2, -3, 11, 12, 15, 16, 18, 100}

        outputTextBox.AppendText(String.Format("Original array:{0}", vbCrLf))
        For Each element In values
            outputTextBox.AppendText(" " & element)
        Next

        Dim filtered = From value In values
                       Where value > 4
                       Select value

        outputTextBox.AppendText(String.Format("{0}{0}Array values greater than 4:{0}", vbCrLf))
        For Each element In filtered
            outputTextBox.AppendText(" " & element)
        Next

        Dim sorted = From value In values
                     Order By value
                     Select value

        outputTextBox.AppendText(String.Format("{0}{0}Original array, sorted:{0}", vbCrLf))
        For Each element In sorted
            outputTextBox.AppendText(" " & element)
        Next
        Dim sortfilteredresilts = From value In filtered
                                  Order By value Descending
                                  Select value

        outputTextBox.AppendText(String.Format("{0}{0}Values greater than 4, descending order (chained):{0}", vbCrLf))
        For Each element In sortfilteredresilts
            outputTextBox.AppendText("   " & element)
        Next

        Dim sortandfilter = From value In values
                            Where value > 4
                            Order By value Descending
                            Select value
        outputTextBox.AppendText(String.Format("{0}{0}Values greater than 4, descending order (one query):{0}", vbCrLf))
        For Each element In sortandfilter
            outputTextBox.AppendText("   " & element)
        Next
        ' extra
        Dim sortandfilter2 = From value In values
                             Where value > 0
                             Order By value Ascending
                             Select value
        outputTextBox.AppendText(String.Format("{0}{0}Values greater than 0, Ascending order:{0}", vbCrLf))
        For Each element In sortandfilter2
            outputTextBox.AppendText("   " & element)
        Next
        Dim oddfilter = From value In values
                        Where value Mod 2 = 1
                        Order By value Descending
                        Select value
        outputTextBox.AppendText(String.Format("{0}{0}Odd number, Descending order:{0}", vbCrLf))
        For Each element In oddfilter
            outputTextBox.AppendText("   " & element)
        Next

        Dim countarray = Aggregate value In values
                   Where value Mod 2 = 1
                   Select value
                   Into Count()

        outputTextBox.AppendText(String.Format("{0}{0}There is {0}" & countarray & " Odd numbers", vbCrLf))
        Dim sumoddarray = Aggregate value In values
                          Where value Mod 2 = 1
                          Select value
                          Into Sum()
        outputTextBox.AppendText(String.Format("{0}{0}The total of odd numbers is:{0}" & sumoddarray, vbCrLf))
    End Sub
End Class
