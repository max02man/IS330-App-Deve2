﻿Public Class Employee
    Public Property lastname As String
    Public Property firstname As String
    Private monthlysalaryvalue As Decimal

    Public Sub New(ByVal first As String, ByVal last As String, ByVal salary As Decimal)
        firstname = first
        lastname = last
        monthlysalaryvalue = salary

    End Sub
    Public Property monthlysalary() As Decimal
        Get
            Return monthlysalaryvalue
        End Get
        Set(ByVal value As Decimal)
            If value >= 0 Then
                monthlysalaryvalue = value
            Else
                Throw New ArgumentOutOfRangeException("Salary must be greater than or equal to 0")
            End If
        End Set
    End Property

    Public Overrides Function ToString() As String
        Return String.Format("{0,-10} {1,-10} {2,-10:c}",
        firstname, lastname, monthlysalary)
    End Function

End Class
