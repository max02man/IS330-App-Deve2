﻿Public Class Form1

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Dim employees() As Employee = {
         New Employee("Jason", "Red", 5000D),
         New Employee("Ashley", "Green", 7600D),
         New Employee("Matthew", "Indigo", 3587.5D),
         New Employee("James", "Indigo", 4700.77D),
         New Employee("Luke", "Indigo", 6200D),
         New Employee("Jason", "Blue", 3200D),
         New Employee("Wendy", "Brown", 4236.4D),
         New Employee("Alaa", "Hawsawi", 10000.9D),
         New Employee("Matt", "Handrson", 7000.5D)}

        outputTextBox.AppendText(String.Format(
         "Original array:{0}", vbCrLf))
        For Each element In employees
            outputTextBox.AppendText(
               String.Format("   {0}{1}", element, vbCrLf))
        Next

        Dim between4K6K =
         From employee In employees
         Where (employee.monthlysalary >= 4000D AndAlso
            employee.monthlysalary <= 6000D)
         Select employee
        outputTextBox.AppendText(String.Format(
        "{0}Employees earning in the range {1:C}-{2:C} per month:{0}",
        vbCrLf, 4000, 6000))
        For Each element In between4K6K
            outputTextBox.AppendText(
               String.Format("   {0}{1}", element, vbCrLf))
        Next
       
        Dim nameSorted =
        From employee In employees
        Order By employee.lastname, employee.firstname
        Select employee

        outputTextBox.AppendText(String.Format(
           "{0}First employee when sorted by name:{0}", vbCrLf))

        If nameSorted.Count() > 0 Then
            outputTextBox.AppendText(nameSorted.First().ToString() & vbCrLf)
        Else
            outputTextBox.AppendText("not found" & vbCrLf)
        End If


        Dim lastNames =
           From employee In employees
           Select employee.lastname
           Distinct


        outputTextBox.AppendText(String.Format(
           "{0}Unique employee last names:{0}", vbCrLf))
        For Each element In lastNames
            outputTextBox.AppendText(
               String.Format("   {0}{1}", element, vbCrLf))
        Next


        Dim names =
           From employee In employees
           Select employee.firstname, employee.lastname


        outputTextBox.AppendText(String.Format(
           "{0}Names only:{0}", vbCrLf))
        For Each element In names
            outputTextBox.AppendText(
               String.Format("   {0}{1}", element, vbCrLf))
        Next

        'extra 
        Dim morethan4k =
         From employee In employees
         Where (employee.monthlysalary > 4000D)
         Select employee
        outputTextBox.AppendText(String.Format(
        "{0}Employees earning in the range {1:C} per month:{0}",
        vbCrLf, 4000))
        For Each element In morethan4k
            outputTextBox.AppendText(
               String.Format("   {0}{1}", element, vbCrLf))
        Next

        Dim avesalary = Aggregate employee In employees
                        Where (employee.monthlysalary > 4000D)
                        Select employee
                        Into Count(), avg = Average(employee.monthlysalary)
        outputTextBox.AppendText(String.Format("{0}There is " & avesalary.Count & " employees" & "{0}The avagrge for the employees who have greater the 4k is {0} " & avesalary.avg.ToString("#.##"), vbCrLf))

        Dim firterIndigo = From employee In employees
                           Where (employee.lastname = "Indigo")
                           Select employee
        outputTextBox1.AppendText(String.Format("{0}Employee who has last name is Indigo: ", vbCrLf) & vbCrLf)
        For Each element In firterIndigo
            outputTextBox1.AppendText(String.Format("{0}{1}", element, vbCrLf))
        Next

        Dim beginwithj = From employee In employees
                         Where (employee.firstname.StartsWith("J"))
                         Select employee
                         Order By employee.monthlysalary Descending
        outputTextBox1.AppendText(String.Format("{0}Employee who first name begin with J: ", vbCrLf) & vbCrLf)
        For Each element In beginwithj
            outputTextBox1.AppendText(String.Format("{0}{1}", element, vbCrLf))
        Next
    End Sub
End Class
